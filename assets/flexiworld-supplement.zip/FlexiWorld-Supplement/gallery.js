/* Offline, frame-aligned playback; no network requests or telemetry. */
'use strict';
const data = window.GALLERY_DATA;
const $ = (id) => document.getElementById(id);
let activeTask = 0, activeCase = 0, videos = [], running = false, generation = 0;
const icons = () => window.lucide.createIcons();
const current = () => data.tasks[activeTask].cases[activeCase];
const maximum = () => current().distance * 2;

function playIcon() {
  $('play').innerHTML = `<i data-lucide="${running ? 'pause' : 'play'}"></i>`;
  const label = running ? 'Pause all videos' : 'Play all videos';
  $('play').title = label;
  $('play').setAttribute('aria-label', label);
  icons();
}
function pause() { running = false; videos.forEach(v => v.pause()); playIcon(); }
function updateStep(step) {
  step = Math.max(0, Math.min(maximum(), step));
  $('timeline').value = step;
  $('step').textContent = `${step} / ${maximum()}`;
  $('phase').textContent = step === maximum() ? 'End of execution budget' :
    step >= current().distance ? 'After reobservation: second plan for unsuccessful episodes' : 'First plan';
}
function seek(step) {
  step = Math.max(0, Math.min(maximum(), Number(step)));
  videos.forEach(v => { if (v.readyState > 0) v.currentTime = step / current().fps; });
  updateStep(step);
}
async function play() {
  if (running) return pause();
  if (videos.some(v => v.readyState < 2)) return;
  if (Number($('timeline').value) >= maximum()) seek(0);
  running = true;
  const token = generation;
  try { await Promise.all(videos.map(v => v.play())); }
  catch (error) { if (token === generation) { pause(); $('media-error').hidden = false; $('media-error').textContent = 'Playback could not start. Open index.html in a current browser after extracting the complete ZIP.'; } }
  if (token === generation) playIcon();
}
function tick() {
  if (running && videos[0]) {
    const time = videos[0].currentTime;
    const step = Math.min(maximum(), Math.floor(time * current().fps + 0.001));
    videos.slice(1).forEach(v => { if (Math.abs(v.currentTime - time) > 0.075 && !v.seeking) v.currentTime = time; });
    updateStep(step);
    if (time >= maximum() / current().fps) { pause(); seek(maximum()); }
  }
  requestAnimationFrame(tick);
}
function outcome(label, value) {
  return `<span class="outcome"><small>${label}</small> <b class="${value ? 'success' : 'failure'}">${value ? 'Success' : 'Failure'}</b></span>`;
}
function renderCase() {
  pause(); generation++;
  const task = data.tasks[activeTask], c = current();
  $('task-title').textContent = task.name;
  $('case-description').textContent = c.description;
  $('case-metadata').textContent = `D = ${c.distance} \u00b7 k = 5 \u00b7 Episode ${c.episode} \u00b7 Start ${c.start}`;
  $('case-number').textContent = `Case ${activeCase + 1} of ${task.cases.length}`;
  $('previous').disabled = activeCase === 0;
  $('next').disabled = activeCase === task.cases.length - 1;
  $('goal').src = c.goal;
  $('goal').alt = `${task.name} shared target, episode ${c.episode}`;
  $('timeline').max = maximum();
  $('midpoint-label').textContent = `Reobservation at ${c.distance}`;
  $('end-label').textContent = maximum();
  $('media-error').hidden = true;
  $('play').disabled = true;
  $('timeline').disabled = true;
  const expert = c.expert;
  $('players').innerHTML = `<figure class="player expert">
    <figcaption class="player-title"><strong>Expert reference</strong><span>Ground-truth trajectory</span></figcaption>
    <div class="video-wrap"><video muted playsinline preload="auto" poster="${expert.poster}" aria-label="Expert reference dataset trajectory" src="${expert.video}"></video></div>
    <div class="outcomes"><span class="outcome"><small>At D:</small> <b>Goal frame</b></span></div>
  </figure>` + c.methods.map(m => `<figure class="player ${m.family === 'FlexiWorld' ? 'ours' : ''}">
    <figcaption class="player-title"><strong>${m.label}</strong><span>${m.search ? 'With search' : 'Without search'}</span></figcaption>
    <div class="video-wrap"><video muted playsinline preload="auto" poster="${m.poster}" aria-label="${m.label} recorded rollout" src="${m.video}"></video></div>
    <div class="outcomes">${outcome('At D:', m.first_success)}${outcome('Final:', m.final_success)}</div>
  </figure>`).join('');
  videos = [...document.querySelectorAll('video')];
  videos.forEach(v => {
    v.playbackRate = Number($('speed').value);
    v.addEventListener('canplay', () => {
      const loading = videos.some(x => x.readyState < 2);
      $('play').disabled = loading; $('timeline').disabled = loading;
    });
    v.addEventListener('error', () => { pause(); $('media-error').hidden = false; $('media-error').textContent = 'A recording could not be loaded. Keep the media folder next to index.html when extracting this supplement.'; });
  });
  updateStep(0);
  document.querySelectorAll('.task-tab').forEach((button, i) => {
    button.setAttribute('aria-selected', String(i === activeTask));
    button.tabIndex = i === activeTask ? 0 : -1;
  });
}
data.tasks.forEach((task, index) => {
  const b = document.createElement('button');
  b.className = 'task-tab'; b.setAttribute('role', 'tab'); b.setAttribute('aria-controls', 'comparison');
  b.innerHTML = `<img src="${task.cases[0].goal}" alt=""><strong>${task.name}</strong>`;
  b.addEventListener('click', () => { activeTask = index; activeCase = 0; renderCase(); });
  b.addEventListener('keydown', e => {
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(e.key)) return;
    e.preventDefault();
    activeTask = e.key === 'Home' ? 0 : e.key === 'End' ? data.tasks.length - 1 :
      (activeTask + (e.key === 'ArrowRight' ? 1 : -1) + data.tasks.length) % data.tasks.length;
    activeCase = 0; renderCase(); $('tasks').children[activeTask].focus();
  });
  $('tasks').append(b);
});
$('play').addEventListener('click', play);
$('restart').addEventListener('click', () => { pause(); seek(0); });
$('timeline').addEventListener('input', e => { pause(); seek(e.target.value); });
$('speed').addEventListener('change', e => videos.forEach(v => { v.playbackRate = Number(e.target.value); }));
$('goal-open').addEventListener('click', () => { pause(); $('goal-large').src = current().goal; $('goal-dialog').showModal(); });
$('goal-close').addEventListener('click', () => $('goal-dialog').close());
$('previous').addEventListener('click', () => { if (activeCase > 0) { activeCase--; renderCase(); } });
$('next').addEventListener('click', () => { if (activeCase < data.tasks[activeTask].cases.length - 1) { activeCase++; renderCase(); } });
document.addEventListener('visibilitychange', () => { if (document.hidden) pause(); });
renderCase(); icons(); requestAnimationFrame(tick);

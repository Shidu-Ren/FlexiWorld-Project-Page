FLEXIWORLD: QUALITATIVE COMPARISONS

Extract the complete archive and open index.html in a current browser.
No server, internet connection, or installation is required.
The media folder also contains ordinary MP4 files and goal/start/final images.

All four benchmarks include a recorded case where FlexiWorld Direct succeeds
but INTACT Direct and Guarded-A fail from the same start and goal. ARCEM is
shown alongside them on the same FlexiWorld checkpoint.
Cube cases additionally require ARCEM success.

Expert reference shows the original dataset trajectory from the identical
episode and start, with its goal frame at D held through the remaining
budget. It is a reference, not an additional evaluated planner.

These cases were selected after observing outcomes. They illustrate specific
behaviors, not representative success rates. New recordings do not replace
the quantitative evaluation results. See the page and manifest.json for
protocol, seed, episode, outcome, and integrity metadata.

Playback follows primitive action steps at 20 fps. Successful episodes hold
their final state; playback duration does not measure planning latency.

Icons: Lucide, ISC license; see LUCIDE-LICENSE.
